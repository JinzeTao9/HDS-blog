// TODO: Add any extra #includes that you need

#include "set.h"
#include <stdlib.h>
#include <string.h>

// TODO: Add your data structure definitions

typedef struct node {
  string data;
  struct node *next;
} NodeT;

struct SetRepr{
  int   length;   // #elements on stack
  NodeT *top;      // ptr to first element
};


// TODO: Fill in these function stubs

set set_create() {
    // TODO: Delete the code below when you're ready to implement this function
    set s = malloc(sizeof(struct SetRepr));
    s->length = 0;
    s->top = NULL;
    return s;
}

void set_destroy(set s) {
    // TODO: Delete the code below when you're ready to implement this function
    NodeT *curr = s->top;
    while (curr != NULL) {
      NodeT *temp = curr->next;
      free(curr->data);
      free(curr);
      curr = temp;
    }
    return;
}

void set_insert(set s, string dat) {
    // TODO: Delete the code below when you're ready to implement this function
    if (set_contains(s, dat)) return ;
    NodeT *new = malloc(sizeof(NodeT));
    new->data = (string)malloc((strlen(dat) + 1) * sizeof(char));
    strcpy(new->data, dat);
    new->next = s->top;
    s->top = new;
    s->length++;
    return;
}

void set_remove(set s, string dat) {
    // TODO: Delete the code below when you're ready to implement this function
    if (!set_contains(s, dat)) return ;
    NodeT *head = s->top;
    s->top = s->top->next;
    s->length--;
    free(head->data);
    free(head);
    return;
}

bool set_contains(set s, string dat) {
    // TODO: Delete the code below when you're ready to implement this function
    if (!s->length) return false;
    NodeT *head = s->top;
    while (head != NULL) {
      if (strcmp(dat, head->data) == 0) return true;
      head = head->next;
    }
    return false;
}
