// TODO: Add any extra #includes that you need

#include "pqueue.h"
#include <stdlib.h>
#include <string.h>
typedef struct node {
  string data;
  priority prio;
  struct node *next;
} NodeT;
// TODO: Add your data structure definitions

struct PriorityQueueRepr {
  int   length;
  NodeT *head;
};


// TODO: Fill in these function stubs


pqueue pqueue_create() {
    // TODO: Delete the code below when you're ready to implement this function
    pqueue pq = (pqueue) malloc(sizeof(struct PriorityQueueRepr));
    pq->length = 0;
    pq->head = NULL;
    return pq;
}

void pqueue_destroy(pqueue pq) {
    // TODO: Delete the code below when you're ready to implement this function
    NodeT *curr = pq->head;
    while (curr != NULL) {
      NodeT *temp = curr->next;
      free(curr->data);
      free(curr);
      curr = temp;
    }
    free(pq);
    return;
}

void pqueue_join(pqueue pq, string dat, priority prio) {
    // TODO: Delete the code below when you're ready to implement this function
    NodeT *new = (NodeT *)malloc(sizeof(NodeT));
    new->prio = prio;
    new->data = (string)malloc((strlen(dat) + 1) * sizeof(char));
    strcpy(new->data, dat);
    new->next = pq->head;
    pq->head = new->next;
}

string pqueue_leave(pqueue pq) {
    // TODO: Delete the code below when you're ready to implement this function
    if (!pq->length) return NULL;
    NodeT *bestNode = NULL, *curr;
    for (curr = pq->head; curr != NULL; curr = curr->next) {
      if (bestNode == NULL) {
        bestNode = curr;
      }
      else if (curr->prio > bestNode->prio){
        bestNode = curr;
      }
    }
    string bestValue = (string)malloc((strlen(bestNode->data) + 1)
                                          * sizeof(char));
    strcpy(bestValue, bestNode->data);
    pq->length--;
    free(bestNode->data);
    free(bestNode);
    return bestValue;
}

string pqueue_peek(pqueue pq) {
    // TODO: Delete the code below when you're ready to implement this function
    if (!pq->length) return NULL;
    NodeT *bestNode = NULL, *curr;
    for (curr = pq->head; curr != NULL; curr = curr->next) {
      if (bestNode == NULL) {
        bestNode = curr;
      }
      else if (curr->prio > bestNode->prio){
        bestNode = curr;
      }
    }
    return bestNode->data;
}

bool pqueue_empty(pqueue pq) {
    // TODO: Delete the code below when you're ready to implement this function
    return !pq->length;
}
