// TODO: Add any extra #includes that you need

#include "graph.h"
#include "dijkstra.h"
#include "pagerank.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"
// TODO: Add your data structure definitions

typedef struct node {
  string data;
  struct node *next, *last;
  struct edge *edges;
  double oldrank, pagerank;
  bool del;
  double path;

} NodeT;

typedef struct edge {
  weight w;
  NodeT *e_node;
  struct edge *next;
} EdgeT;

struct GraphRepr {
  NodeT *vertices;
};

NodeT *graph_get_vertex(graph g, string v) {
  NodeT *curr = g->vertices;
  while (curr != NULL) {
    if (strcmp(curr->data, v) == 0) {
      return curr;
    }
    curr = curr->next;
  }
  return NULL;
}

// TODO: Fill in these function stubs

graph graph_create(void) {
  // TODO: Delete the code below when you're ready to implement this function
  graph g = (graph)malloc(sizeof(struct GraphRepr));
  g->vertices = NULL;
  return g;
}

void graph_destroy(graph g) {
  // TODO: Delete the code below when you're ready to implement this function
  NodeT *curr = g->vertices, *det;
  while (curr != NULL) {
    EdgeT *curr_e = curr->edges, *det_e;
    while (curr_e != NULL) {
      det_e = curr_e;
      curr_e = curr_e->next;
      free(det_e);
    }
    det = curr;
    curr = curr->next;
    free(det->data);
    free(det);
  }
  free(g);
}

void graph_add_vertex(graph g, string v) {
  // TODO: Delete the code below when you're ready to implement this function
  if (!graph_has_vertex(g, v)) {
    NodeT *new = (NodeT *)malloc(sizeof(NodeT));
    new->edges = NULL;
    new->data = (string)malloc((strlen(v) + 1) * sizeof(char));
    strcpy(new->data, v);
    NodeT *curr = g->vertices;
    if (curr == NULL) {
      g->vertices = new;
      new->next = NULL;
    } else {
      while (curr->next != NULL) {
        curr = curr->next;
      }
      curr->next = new;
      new->next = NULL;
    }
  }
}

bool graph_has_vertex(graph g, string v) {
  // TODO: Delete the code below when you're ready to implement this function
  if (graph_get_vertex(g, v) == NULL)
    return false;
  return true;
}

size_t graph_vertices_count(graph g) {
  // TODO: Delete the code below when you're ready to implement this function
  size_t counts = 0;
  NodeT *curr = g->vertices;
  while (curr != NULL) {
    counts = counts + 1;
    curr = curr->next;
  }
  return counts;
}

void graph_add_edge(graph g, string v1, string v2, weight w) {
  // TODO: Delete the code below when you're ready to implement this function
  if (!graph_has_edge(g, v1, v2)) {
    NodeT *u = graph_get_vertex(g, v1);
    NodeT *v = graph_get_vertex(g, v2);
    EdgeT *new = (EdgeT *)malloc(sizeof(EdgeT)), *curr = u->edges;
    new->e_node = v;
    new->w = w;
    if (curr == NULL) {
      u->edges = new;
      new->next = NULL;
    } else {
      while (curr->next != NULL) {
        curr = curr->next;
      }
      curr->next = new;
      new->next = NULL;
    }
  }
}

bool graph_has_edge(graph g, string v1, string v2) {
  // TODO: Delete the code below when you're ready to implement this function
  NodeT *u = graph_get_vertex(g, v1);
  NodeT *v = graph_get_vertex(g, v2);
  if (u == NULL || v == NULL)
    return false;
  EdgeT *curr = u->edges;
  while (curr != NULL) {
    if (curr->e_node == v)
      return true;
    curr = curr->next;
  }
  return false;
}

void graph_update_edge(graph g, string v1, string v2, weight w) {
  // TODO: Delete the code below when you're ready to implement this function
  NodeT *u = graph_get_vertex(g, v1);
  NodeT *v = graph_get_vertex(g, v2);
  if (graph_has_edge(g, v1, v2)) {
    EdgeT *curr = u->edges;
    while (curr != NULL) {
      if (curr->e_node == v) {
        curr->w = w;
        break;
      }
      curr = curr->next;
    }
  } else {
    graph_add_edge(g, v1, v2, w);
  }
  return;
}

weight graph_get_edge(graph g, string v1, string v2) {
  // TODO: Delete the code below when you're ready to implement this function
  NodeT *u = graph_get_vertex(g, v1);
  NodeT *v = graph_get_vertex(g, v2);
  if (u == NULL || v == NULL)
    return 0.0;
  if (!graph_has_edge(g, v1, v2))
    return 0.0;
  EdgeT *curr = u->edges;
  while (curr != NULL) {
    if (curr->e_node == v) {
      return curr->w;
    }
    curr = curr->next;
  }
  return 0.0;
}

size_t graph_edges_count(graph g, string v) {
  // TODO: Delete the code below when you're ready to implement this function
  size_t counts = 0;
  NodeT *u = graph_get_vertex(g, v), *curr = g->vertices;
  EdgeT *curr_e = u->edges;
  while (curr_e != NULL) {
    counts = counts + 1;
    curr_e = curr_e->next;
  }
  while (curr != NULL) {
    curr_e = curr->edges;
    while (curr_e != NULL) {
      if (curr_e->e_node == u) {
        counts = counts + 1;
      }
      curr_e = curr_e->next;
    }
    curr = curr->next;
  }
  return counts;
}

void graph_show(graph g, FILE *output) {
  // TODO: Delete the code below when you're ready to implement this function
  if (output == NULL) {
    output = stdout;
  }
  NodeT *curr = g->vertices;
  while (curr != NULL) {
    fprintf(output, "%s\n", curr->data);
    curr = curr->next;
  }
  curr = g->vertices;
  while (curr != NULL) {
    EdgeT *curr_e = curr->edges;
    while (curr_e != NULL) {
      fprintf(output, "%s %s %.3f\n", curr->data, curr_e->e_node->data,
              curr_e->w);
      curr_e = curr_e->next;
    }
    curr = curr->next;
  }
  return;
}

void graph_pagerank(graph g, double damping, double delta) {
  // TODO: Delete the code below when you're ready to implement this function
  size_t N = graph_vertices_count(g);
  NodeT *curr, *curr_v;
  curr = g->vertices;
  while (curr != NULL) {
    curr->oldrank = 0.0;
    curr->pagerank = 1.0 / N;
    curr = curr->next;
  }
  while (true) {
    bool end = true;
    curr = g->vertices;
    while (curr != NULL) {
      if (fabs(curr->pagerank - curr->oldrank) > delta)
        end = false;
      curr = curr->next;
    }
    if (end) {
      break;
    }
    curr = g->vertices;
    while (curr != NULL) {
      curr->oldrank = curr->pagerank;
      curr = curr->next;
    }
    double sink_rank = 0;
    curr = g->vertices;
    while (curr != NULL) {
      if (curr->edges == NULL) {
        sink_rank = sink_rank + (damping * (curr->oldrank / N));
      }
      curr = curr->next;
    }
    curr = g->vertices;
    while (curr != NULL) {
      curr->pagerank = sink_rank + ((1 - damping) / N);
      curr_v = g->vertices;
      while (curr_v != NULL) {
        if (graph_has_edge(g, curr_v->data, curr->data)) {
          size_t out_counts = 0;
          EdgeT *curr_e = curr_v->edges;
          while (curr_e != NULL) {
            out_counts = out_counts + 1;
            curr_e = curr_e->next;
          }
          curr->pagerank =
              curr->pagerank + ((damping * curr_v->oldrank) / out_counts);
        }
        curr_v = curr_v->next;
      }
      curr = curr->next;
    }
  }
}

void graph_show_pagerank(graph g, FILE *file) {
  // TODO: Delete the code below when you're ready to implement this function
  NodeT *curr = g->vertices, *maxNode;
  while (curr != NULL) {
    curr->del = false;
    curr = curr->next;
  }
  size_t N = graph_vertices_count(g);
  for (size_t i = 0; i < N; i++) {
    maxNode = NULL;
    curr = g->vertices;
    while (curr != NULL) {
      if (curr->del == false) {
        if (maxNode == NULL)
          maxNode = curr;
        else {
          if (maxNode->pagerank < curr->pagerank ||
              (curr->pagerank == maxNode->pagerank &&
               strcmp(curr->data, maxNode->data) < 0)) {
            maxNode = curr;
          }
        }
      }
      curr = curr->next;
    }
    maxNode->del = true;
    fprintf(file, "%s (%.3f)\n", maxNode->data, maxNode->pagerank);
  }

  return;
}

void graph_worst_path(graph g, string source, double damping, double delta) {
  // TODO: Delete the code below when you're ready to implement this function
  graph_pagerank(g, damping, delta);
  NodeT *s = graph_get_vertex(g, source);
  NodeT *curr = g->vertices;
  while (curr != NULL) {
    curr->path = 1e15;
    curr->last = NULL;
    curr->del = false;
    curr = curr->next;
  }
  s->path = 0;
  size_t N = graph_vertices_count(g);
  for (size_t i = 0; i < N; i++) {
    NodeT *worstNode = NULL;
    curr = g->vertices;
    while (curr != NULL) {
      if (curr->del == false) {
        if (worstNode == NULL) {
          worstNode = curr;
        }
        else {
          if (worstNode->path > curr->path) {
            worstNode = curr;
          }
        }
      }
      curr = curr->next;
    }
    worstNode->del = true;
    EdgeT *curr_e = worstNode->edges;
    while (curr_e != NULL) {
      if (curr_e->e_node->path > worstNode->path + curr_e->e_node->pagerank) {
        curr_e->e_node->path = worstNode->path + curr_e->e_node->pagerank;
        curr_e->e_node->last = worstNode;
      }
      curr_e = curr_e->next;
    }
  }
  return;
}

void graph_show_path(graph g, string destination) {
  // TODO: Delete the code below when you're ready to implement this function
  NodeT *dest = graph_get_vertex(g, destination);
  if (dest->last == NULL) {
    printf("No path found.\n");
  }
  else {
    stack s;
    s = stack_create();
    while (dest != NULL) {
      stack_push(s, dest->data);
      dest = dest->last;
    }
    size_t length = 0;
    while (!stack_empty(s)) {
      string data = stack_pop(s);
      if (length != 0) printf("-> ");
      printf("%s\n", data);
      length++;
      free(data);
    }
    stack_destroy(s);
  }

  return;
}
