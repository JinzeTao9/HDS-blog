// TODO: Add any extra #includes that you need

#include "stack.h"
#include <stdlib.h>
#include <string.h>

// TODO: Add your data structure definitions

typedef struct node {
  string data;
  struct node *next;
} NodeT;

struct StackRepr {
  int    height;   // #elements on stack
  NodeT *top;      // ptr to first element
} ;


// TODO: Fill in these function stubs


stack stack_create() {
    // TODO: Delete the code below when you're ready to implement this function
    stack s = (stack)malloc(sizeof(struct StackRepr));
    s->height = 0;
    s->top = NULL;
    return s;
}

void stack_destroy(stack s) {
    // TODO: Delete the code below when you're ready to implement this function
    NodeT *curr = s->top;
    while (curr != NULL) {
      NodeT *temp = curr->next;
      free(curr->data);
      free(curr);
      curr = temp;
    }
    free(s);
}

void stack_push(stack s, string dat) {
    // TODO: Delete the code below when you're ready to implement this function
    NodeT *new = malloc(sizeof(NodeT));
    new->data = (string)malloc((strlen(dat) + 1) * sizeof(char));
    strcpy(new->data, dat);
    new->next = s->top;
    s->top = new;
    s->height++;
    return;
}

string stack_pop(stack s) {
    // TODO: Delete the code below when you're ready to implement this function
    if (!s->height) return NULL;
    NodeT *head = s->top;
    s->top = s->top->next;
    s->height--;
    string d = (string)malloc((strlen(head->data) + 1) * sizeof(char));
    strcpy(d, head->data);
    free(head->data);
    free(head);
    return d;
}

string stack_peek(stack s) {
    // TODO: Delete the code below when you're ready to implement this function
    if (!s->height) return NULL;
    return s->top->data;
}

bool stack_empty(stack s) {
    // TODO: Delete the code below when you're ready to implement this function
    return s->height == 0;
}
