// TODO: Add any extra #includes that you need

#include "queue.h"
#include <stdlib.h>
#include <string.h>

typedef struct node {
  string data;
  struct node *next;
} NodeT;
// TODO: Add your data structure definitions

struct QueueRepr {
  int   length;
  NodeT *head;
  NodeT *tail;
};


// TODO: Fill in these function stubs


queue queue_create() {
    // TODO: Delete the code below when you're ready to implement this function
    queue q = malloc(sizeof(struct QueueRepr));
    q->length = 0;
    q->head = NULL;
    q->tail = NULL;
    return q;
}

void queue_destroy(queue q) {
    // TODO: Delete the code below when you're ready to implement this function
    NodeT *curr = q->head;
    while (curr != NULL) {
      NodeT *temp = curr->next;
      free(curr->data);
      free(curr);
      curr = temp;
    }
    free(q);
    return;
}

void queue_enqueue(queue q, string dat) {
    // TODO: Delete the code below when you're ready to implement this function
    NodeT *new = malloc(sizeof(NodeT));
    new->data = (string)malloc((strlen(dat) + 1) * sizeof(char));
    strcpy(new->data, dat);
    new->next = NULL;
    if (q->tail != NULL) {
      q->tail->next = new;
      q->tail = new;
    } else {
      q->head = new;
      q->tail = new;
    }
    q->length++;
    return;
}

string queue_dequeue(queue q) {
    // TODO: Delete the code below when you're ready to implement this function
    NodeT *p = q->head;
    q->head = q->head->next;
    if (q->head == NULL) {
      q->tail = NULL;
    }
    q->length--;
    string d = (string)malloc((strlen(p->data) + 1) * sizeof(char));
    strcpy(d, p->data);
    free(p->data);
    free(p);
    return d;
}

string queue_peek(queue q) {
    // TODO: Delete the code below when you're ready to implement this function
    return q->head->data;
}

bool queue_empty(queue q) {
    // TODO: Delete the code below when you're ready to implement this function
    return q->length == 0;
}
